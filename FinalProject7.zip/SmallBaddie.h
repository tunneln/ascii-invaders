//SmallBaddie.h
#ifndef	__SmallBaddie_H_INCLUDED__
#define	__SmallBaddie_H_INCLUDED__

#include "EnemyShip.h"

class SmallBaddie: public EnemyShip{

	public:
		SmallBaddie();
		SmallBaddie(int, int);
};

#endif
