//PlayerShip.cpp
#include "PlayerShip.h"

PlayerShip::PlayerShip(){
	type = '^';
}
PlayerShip::PlayerShip(int a, int b){
	x = a;
	y = b;
	type = '^';
}
