//PlayerShip.h
#ifndef	__PlayerShip_H_INCLUDED__
#define	__PlayerShip_H_INCLUDED__

#include "Ship.h"

class PlayerShip: public Ship{
	
	public:
		PlayerShip();
		PlayerShip(int a, int b);
};

#endif
