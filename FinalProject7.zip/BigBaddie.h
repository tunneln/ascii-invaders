//BigBaddie.h
#ifndef	__BigBaddie_H_INCLUDED__
#define	__BigBaddie_H_INCLUDED__

#include "EnemyShip.h"

class BigBaddie: public EnemyShip{

	public:
		BigBaddie();
		BigBaddie(int, int);
};

#endif
